<?php
    $db_host = "sql113.epizy.com";
    $db_username = "epiz_31696241";
    $db_pass = "epiz_31696241";
    $db_table = "epiz_31696241_catalogdb";

    $con = new mysqli($db_host, $db_username, $db_pass, $db_table) or die(mysqli_error());

    
    
?>